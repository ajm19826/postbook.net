function getElementByClassFeatures() {
    document.write("An error occured. \n Please try again later")
    console.warn("ERROR: An error occured! Please refresh the system.")
    window.open("file:///D:\Desktop - Alex\PostBook - Social Media\!System64\trascript.html")
}