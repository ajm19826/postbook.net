[pws-msg]
================================
To enable this hidden registry key, please enable "Show hidden folders and files."